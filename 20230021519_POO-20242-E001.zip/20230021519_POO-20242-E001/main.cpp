#include <iostream>
#include "exchange.h"

using namespace std;

int main() {
	Carteira carteira1(100,100,100), carteira2(200,200,200), carteira3(300,300,300);
	Transacao transacao1, transacao2, transacao3, transacao4;
	Exchange exchange;
	
	carteira1.setEndereco(&carteira1);
	carteira2.setEndereco(&carteira2);
	carteira3.setEndereco(&carteira3);
	
	exchange.adicionar_carteira(carteira1);
	exchange.adicionar_carteira(carteira2);
	exchange.adicionar_carteira(carteira3);
	
	cout << endl << "=== Estado Inicial das Carteiras ===" << endl << endl;
	exchange.exibir_carteiras();
	
	cout << "=== Realizando Transa��es ===" << endl << endl;
	
	exchange.realizar_transacao(transacao1, "COMPRA", "BTC", "BRL", 50, 2, &carteira2, &carteira1);
	exchange.realizar_transacao(transacao2, "VENDA", "ETH", "BTC", 20, 1, &carteira1, &carteira3);
	exchange.realizar_transacao(transacao3, "COMPRA", "BTC", "BRL", 20, 400, &carteira3, &carteira2);
	exchange.realizar_transacao(transacao4, "VENDA", "ETH", "BRL", 4000, 0.0003, &carteira2, &carteira3);
	
	exchange.adicionar_carteira(carteira1);
	exchange.adicionar_carteira(carteira2);
	exchange.adicionar_carteira(carteira3);

	cout << "=== Estado Final das Carteiras ===" << endl << endl;
	
	exchange.exibir_carteiras();
	
	return 0;
}
